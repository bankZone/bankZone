# Adding a manifest file placeholder in Kotlin.

See [manifest placeholder documentation](https://developer.android.com/studio/build/manifest-build-variables) for details
This sample shows how to add a manifest placeholder value through the variant API.